<?php 
session_start();

session_unset($_SESSION['admin']);

 ?>

 <script>
 	window.location='index.php';
 </script>